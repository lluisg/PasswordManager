Hello to PasswordManager96!, here's a little help before starting.

The first user and password the program is going to ask you are the ones that you will be using to protect the other passwords, as so it will be the only password not stored, be cautios and don't forget it!

You will see that whenever there's an action with the passwords, some element will be asked or showed. This elements are as follows:

- name: it references at how you will identify the password, it's important as it's the one that will identify for what is that password, and it's the part that will be asked to identify it when searching and the first part that will be shown.

- user: usually (especially online), when a password is asked it goes along with a user, so the passwords will also contain a username

- password: the password itself

- tag: it references to some kind of indicator. Its intention is to help find that password that you are searching for and/or allow to group some passwords together. Only one allowed per password.

#-------------------------------------------------------------------

Wherever the executable file for the program is, two more files will appear: user.info and passwords.info.
The important part to allow this program running perfectly is to have these two files always at the same folder as the executable.

You can recover the passwords, if loose the user file, but not viceversa. (It's pretty obvious but if you try to acces the password file which is not realted to the user logged, it will give an error)

#-------------------------------------------------------------------

It is recommended to have only one instance of the program open apart from the fact that is not necesary to have multiple instances, I don't really know how it could react as trying to access the files at the same time (although I suppose that it would not give any problem really, but I can't really assure 100%)

#-------------------------------------------------------------------

Made by Lluis Guardia.
Only for Windows
